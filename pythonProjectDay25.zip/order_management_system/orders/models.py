from django.db import models
from customers.models import Customer
from products.models import Product

# Create your models here.
class Orders(models.Model):
    consumers = models.ForeignKey(Customer,on_delete=models.CASCADE,related_name="ordered_by")
    orders = models.ForeignKey(Product,on_delete=models.CASCADE,related_name="ordered_product")

    def __str__(self):
        return f"{self.consumers.firstname}-{self.orders.name}"